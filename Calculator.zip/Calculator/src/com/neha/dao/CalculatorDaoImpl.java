package com.neha.dao;

public class CalculatorDaoImpl implements ICalculatorDao {

	 double loanAmount;
	 double Salary;
	 int tenure;
	double rateOfInterest;
   double emi;
   

	@Override
	public double calculateEMI(double loanAmount, double tenure, double RateOfInterest)
	{
		emi=(loanAmount*RateOfInterest *(double)Math.pow(1+RateOfInterest, tenure))/(float)(Math.pow(1+RateOfInterest,tenure)-1);
		
		return emi;
		
	
	}

	@Override
	public double calculateTotalLoan(double salary) {
		 loanAmount=60*(0.6*salary);
			return loanAmount;
	}

	@Override
	public double calculateTotalInterest(double loanAmount, double totalAmtPayable) {
		// TODO Auto-generated method stub
		return 0;
	}

	
