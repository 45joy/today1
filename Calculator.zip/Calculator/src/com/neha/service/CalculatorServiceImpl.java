package com.neha.service;

import com.neha.dao.ICalculatorDao;

public class CalculatorServiceImpl  implements ICalculatorService{
	

	@Autowired
	public void setCalculatorDao(ICalculatorDao calDao) {
		this.calDao = calDao;
	}

	@Override
	public double calculateEMI(EMI e) {
		return this.emiDao.calculateEMI(e);
	}

	
	
	
	
	
	public ICalculatorDao getCalculatordao() {
		return calculatordao;
	}

	public void setCalculatordao(ICalculatorDao calculatordao) {
		this.calculatordao = calculatordao;
	}

	private ICalculatorDao calculatordao;
	
	
	
	
	
	
	

}
