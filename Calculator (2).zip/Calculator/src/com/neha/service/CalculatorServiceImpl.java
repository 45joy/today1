package com.neha.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.neha.dao.ICalculatorDao;
@Service
public class CalculatorServiceImpl  implements ICalculatorService{
	private ICalculatorDao caldao;

	/*@Autowired
	public void setCalculatorDao(ICalculatorDao calDao) {
		this.calDao = calDao;
	}

	@Override
	public double calculateEMI(EMI e) {
		return this.emiDao.calculateEMI(e);
	}*/
@Autowired
	public void setCalculatordao(ICalculatorDao calculatordao) {
		this.caldao = calculatordao;
	}



	@Override
	@Transactional
	public double calculateTotalLoan(double Salary) {
		
		return this.caldao.calculateTotalLoan(Salary);
	}
	
	
	
	
	
	
	

}
