package com.neha.service;
@Service
public interface ICalculatorService {

	
	//	public double calculateTotalEMI(EMI e);

		public double calculateTotalLoan(double Salary);

		//public double calculateTotalInterest(double loanAmount, double totalAmtPayable);
	}

	
	
	
}
