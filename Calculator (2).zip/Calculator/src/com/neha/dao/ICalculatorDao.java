package com.neha.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface ICalculatorDao {

	public double calculateEMI(double loanAmount, double tenure,double RateOfInterest );
	public double calculateTotalLoan(double salary);
	public double calculateTotalInterest(double loanAmount, double totalAmtPayable);
	//double calculateEMI();
	
	

	
	
}
	

	

	
