package com.neha.dao;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;



@Repository
public class CalculatorDaoImpl implements ICalculatorDao {

	 double loanAmount;
	 double Salary;
	 int tenure;
	double rateOfInterest=8.5;
   double emi;
   @Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	
	private static final Logger logger = 			
			LoggerFactory.getLogger(CalculatorDaoImpl.class);
	

	@Override
	public double calculateEMI(double loanAmount, double tenure, double RateOfInterest)
	{
		emi=(loanAmount*RateOfInterest *(double)Math.pow(1+RateOfInterest, tenure))/(float)(Math.pow(1+RateOfInterest,tenure)-1);
		
		return emi;
		
	
	}

	@Override
	public double calculateTotalLoan(double salary) {
		 loanAmount=60*(0.6*salary);
			return loanAmount;
	}

	@Override
	public double calculateTotalInterest(double loanAmount, double totalAmtPayable) {
		// TODO Auto-generated method stub
		return 0;
	}

	//@Override
//	public double calculateTotalInterest(double loanAmount, double totalAmtPayable) {
		// TODO Auto-generated method stub

}

	
