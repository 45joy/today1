package com.neha.service;

import org.springframework.stereotype.Service;

@Service
public interface ICalculatorService {

	
	//	public double calculateTotalEMI(EMI e);

		public double calculateTotalLoan(double Salary);

		//public double calculateTotalInterest(double loanAmount, double totalAmtPayable);
	}

	
	
	

