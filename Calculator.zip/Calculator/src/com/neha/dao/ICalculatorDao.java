package com.neha.dao;

public interface ICalculatorDao {

	public double calculateEMI(double loanAmount, double tenure,double RateOfInterest );
	public double calculateTotalLoan(double salary);
	public double calculateTotalInterest(double loanAmount, double totalAmtPayable);
	//double calculateEMI();
	
	}

	
	
}
	

	

	
