package com.dao;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.model.Documents1;


@Resource
public class DocumentdaoImpl {

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void save(Documents1 document) {
		Session session = sessionFactory.openSession();
		session.persist(document);
		session.flush();
		session.close();
	}

	@Transactional
	public List<Documents1> list() {
		Session session = sessionFactory.openSession();
		List<Documents1> documents = null;
		try {
			documents = (List<Documents1>) session.createQuery("from Document").list();

		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return documents;
	}

	@Transactional
	public Documents1 get(Integer id) {
		Session session = sessionFactory.openSession();
		Documents1 doc = (Documents1) session.get(Documents1.class, id);
		session.close();
		return doc;
	}

	@Transactional
	public void remove(Integer id) {
		Session session = sessionFactory.openSession();

		Documents1 document = (Documents1) session.get(Documents1.class, id);

		session.delete(document);
	}
}
	
	
	

