package com.neha.model;

import org.springframework.stereotype.Component;

@Component
public class Calculator {

	double Salary;
	double loanAmount;
	int tenure;
	double rateOfInterest;

    
	public Calculator(double salary, double loanAmount, int tenure, double rateOfInterest) {
		super();
		this.Salary = salary;
		this.loanAmount = loanAmount;
		this.tenure = tenure;
		this.rateOfInterest = rateOfInterest;
	}


	
	
	public double getLoanAmount() {
		return loanAmount;
	}
	public int getTenure() {
		return tenure;
	}
	public double getRateOfInterest() {
		return rateOfInterest;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public void setRateOfInterest(double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	
 public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		this.Salary = salary;
	}
	public Calculator(Double Salary) {
	this.Salary=Salary;
	}
	 @Override
		public String toString() {
			return "Calculator [Salary=" + Salary + ", loanAmount=" + loanAmount + ", tenure=" + tenure
					+ ", rateOfInterest=" + rateOfInterest + "]";
		}
	
	
}
