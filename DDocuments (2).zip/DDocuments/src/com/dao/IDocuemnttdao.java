package com.dao;

import java.util.List;

import com.model.Documents1;



   public interface IDocuemnttdao {

public void remove(Integer id);

public Documents1 get(Integer id);

public List<Documents1> list();

public void save(Documents1 document);

}